
public interface Computer {
	
	public abstract String getComputerRam();
	public abstract String getComputerHDD();
	public abstract String getComputerCPU();
	public abstract String showSpecs();
}
