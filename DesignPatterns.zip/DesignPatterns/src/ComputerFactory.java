
public class ComputerFactory {

	/**
	 * This method is for creating computer with provided specifications
	 * @param type
	 * @param ram
	 * @param hdd
	 * @param cpu
	 * @return
	 */
	public static Computer getComputer(String type, String ram, String hdd, String cpu) {
		
		if("PC".equalsIgnoreCase(type))
			return new PersonalComputer(ram, hdd, cpu);
		else if("SERVER".equalsIgnoreCase(type))
			return new ServerComputer(ram, hdd, cpu);
		else
			return null;
	}
}
