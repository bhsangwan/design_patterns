
public class EagerSingletonUsingStaticBlock {

	private static EagerSingletonUsingStaticBlock instance;

	private EagerSingletonUsingStaticBlock() {
	}

	static {
		try {
			instance = new EagerSingletonUsingStaticBlock();
		} catch (Exception e) {
			System.out.println("Problem occured while creating instance..!");
		}
	}

	public static EagerSingletonUsingStaticBlock getInstance() {
		return instance;
	}

	public void makeConnection() {
		System.out.println("Connecting with DB...");
	}
}
