package FacasePattern;

public class Client {

	public static void main(String[] args) {
		
		ShopKeeper boy = new ShopKeeper();
		
		boy.displayItem1();
		
		boy.displayItem2();

	}

}
