package FacasePattern;

public class Item2 implements Shop{

	@Override
	public void itemModel() {
		System.out.println("Model : IT2024_1");
		
	}

	@Override
	public void itemPrice() {
		System.out.println("Price : 1500");
		
	}
}
