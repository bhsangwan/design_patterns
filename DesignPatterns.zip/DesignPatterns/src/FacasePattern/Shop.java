package FacasePattern;

public interface Shop {

	public void itemModel();
	public void itemPrice();
	
}
