package FacasePattern;

public class ShopKeeper {

	public Shop item1;
	public Shop item2;
	
	public ShopKeeper() {
		item1 = new Item1();
		item2 = new Item2();
	}
	
	public void displayItem1() {
		item1.itemModel();
		item1.itemPrice();
	}
	
	public void displayItem2() {
		item2.itemModel();
		item2.itemPrice();
	}
}
