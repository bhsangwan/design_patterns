//Singleton (Eager initialization)

public class MySingleton {
	
	private final static MySingleton mySingletonInstance = new MySingleton();
	
	private MySingleton() {}
	
	public static MySingleton getInstance() {
		return mySingletonInstance;
	}

	public void makeConnection() {
		System.out.println("Connecting with DB...");
	}
}
