
public class PersonalComputer implements Computer{
	
	private String ram;
	private String hdd;
	private String cpu;
	
	public PersonalComputer(String ram, String hdd, String cpu) {
		this.ram = ram;
		this.hdd = hdd;
		this.cpu = cpu;
	}
	
	@Override
	public String getComputerRam() {
		return this.ram;
	}

	public String getComputerHDD() {
		return this.hdd;
	}
	
	public String getComputerCPU() {
		return this.cpu;
	}
	
	public String showSpecs() {
		return "Personal Computer - "+ram+"|"+hdd+"|"+cpu;
	}
}
