package StrategyPattern;

import java.util.ArrayList;
import java.util.List;

public class Cart {

	List<Item> items;
	
	public Cart() {
		items = new ArrayList<Item>();
	}
	
	public boolean addItem(Item item) {
		items.add(item);
		return true;
	}
	
	public int finalCheckout() {
		int totalAmount = 0;
		
		for(Item item : items) {
			totalAmount = totalAmount + item.getPrice();
		}
		
		return totalAmount;
	}
	
	public void makePayment(PaymentStrategy strategy) {
		strategy.pay(finalCheckout());
	}
	
}












