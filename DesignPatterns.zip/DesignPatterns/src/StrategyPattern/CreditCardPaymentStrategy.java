package StrategyPattern;

public class CreditCardPaymentStrategy implements PaymentStrategy{

	private String cardNumber;
	private String name;
	private String cvv;
	private String dateOfExpiry;
	
	public CreditCardPaymentStrategy() {}
	
	public CreditCardPaymentStrategy(String cardNumber, String name, String cvv, String dateOfExpiry) {
		super();
		this.cardNumber = cardNumber;
		this.name = name;
		this.cvv = cvv;
		this.dateOfExpiry = dateOfExpiry;
	}
	
	@Override
	public void pay(int amount) {
		System.out.println(amount + " has been debited from you credit card ending with "+cardNumber);
	}
}
