package StrategyPattern;

public class Item {

	private String itemCode;
	private int itemPrice;
	
	public Item() {}

	public Item(String itemCode, int itemPrice) {
		super();
		this.itemCode = itemCode;
		this.itemPrice = itemPrice;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public int getPrice() {
		return itemPrice;
	}

	public void setPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}
	
	public String toString() {
		return itemCode+"|"+itemPrice;
	}
}
