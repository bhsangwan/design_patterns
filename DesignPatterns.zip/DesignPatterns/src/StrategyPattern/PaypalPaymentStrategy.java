package StrategyPattern;

public class PaypalPaymentStrategy implements PaymentStrategy{

	private String email;
	private String username;
	private String password;
	
	public PaypalPaymentStrategy() {}

	public PaypalPaymentStrategy(String email, String username, String password) {
		super();
		this.email = email;
		this.username = username;
		this.password = password;
	}
	
	@Override
	public void pay(int amount) {
		System.out.println("Hi "+username +", "+ amount + " paid from your paypal account..!");
	}
	
}
