package StrategyPattern;

public class Test {

	public static void main(String[] args) {
		
		Cart cart = new Cart();
		
		Item item1 = new Item("IT2424", 1200);
		Item item2 = new Item("IT2525", 2000);
		
		cart.addItem(item2);
		cart.addItem(item1);
		
		//cart.makePayment(new CreditCardPaymentStrategy("12344322", "Bhavesh", "311", "2ndNov"));
		
		cart.makePayment(new PaypalPaymentStrategy("bhsangwan@gmail.com","bhsangwan","xxxxx"));
	}

}
