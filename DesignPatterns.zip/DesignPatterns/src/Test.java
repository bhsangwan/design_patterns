
public class Test {

	public static void main(String[] args) {
		
		//MySingleton instance = MySingleton.getInstance();

		//instance.makeConnection();
		
		//EagerSingletonUsingStaticBlock.getInstance().makeConnection();
		
		Computer myComputer = ComputerFactory.getComputer("pc", "16GB", "128GB", "Intel i5");
		
		System.out.println(myComputer.showSpecs());
		
	
	}

}
